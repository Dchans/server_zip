from django.db import models
from django.conf import settings
from django.db import models

class address(models.Model):
    address1=models.TextField()
    address2=models.TextField()
    address3=models.TextField()
    pincode=models.CharField(max_length=255)   
    def __str__(self):
        return self.address1
class bill_series(models.Model):
    user=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    series=models.CharField(max_length=1)
    range=models.IntegerField(default=10000)
    timestamp=models.DateTimeField(null=True)
    def __str__(self):
        return self.user.name
class bill_rseries(models.Model):
    user=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    series=models.CharField(max_length=1)
    range=models.IntegerField(default=10000)
    timestamp=models.DateTimeField(null=True)
    def __str__(self):
        return self.user.name
class bill_jseries(models.Model):
    user=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    series=models.CharField(max_length=1)
    range=models.IntegerField(default=10000)
    timestamp=models.DateTimeField(null=True)
    def __str__(self):
        return self.user.name
class token_series(models.Model):
    user=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    series=models.CharField(max_length=1)
    range=models.IntegerField(default=10000)
    selected=models.BooleanField(default=False)
    timestamp=models.DateTimeField(null=True)
    def __str__(self):
        return self.user.name
class interest_setting(models.Model):
    user=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    amount1=models.IntegerField()
    amount2=models.IntegerField()
    rate=models.IntegerField()
    type=models.CharField(max_length=1,choices=(("0","GOLD"),("1","SILVER")))
    timestamp=models.DateTimeField(null=True)
    def __str__(self):
        return self.user.name
class suggestion(models.Model):
    name=models.CharField(max_length=255)
    stype=models.CharField(max_length=1,choices=(("0","GOLD"),("1","SILVER")))
    type=models.CharField(max_length=1,choices=(("0","Item"),("1","Description"),("2","Jitems")))
    count=models.IntegerField(default=0)
    class Meta:
        unique_together = ['name', 'type']
    def __str__(self):
        return self.name
class customer(models.Model):
    user=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    name=models.CharField(max_length=255)
    relation=models.CharField(max_length=1,choices=(("0",'S/O'), ("1",'D/O'), ("2",'W/O')))
    relation_name=models.CharField(max_length=255)
    adno=models.CharField(max_length=255)
    address=models.IntegerField()
    phno=models.CharField(max_length=10)
    email=models.EmailField()
    otherval=models.CharField(max_length=255)
    image=models.ImageField(upload_to="images/customer",blank=True, null=True)
    lastactive=models.DateTimeField(null=True)
    timestamp=models.DateTimeField(null=True)
    def __str__(self):
        return self.user.name
class pawn_bills(models.Model):
    user=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    date_created=models.DateField(auto_now_add=True)
    customer_name=models.ForeignKey(customer,on_delete=models.CASCADE,null=True)
    series=models.CharField(max_length=10)
    billno=models.IntegerField()
    weight=models.IntegerField(default=0)
    value=models.IntegerField(default=0)
    amount=models.IntegerField(default=0)
    interest_rate=models.IntegerField(default=0)
    pay=models.IntegerField(default=0)
    rseries=models.CharField(max_length=10,null=True,blank=True)
    redemptiondate=models.DateField(null=True)
    redemption=models.IntegerField(null=True)
    recieved=models.IntegerField(null=True)
    month=models.IntegerField(default=0)
    items=models.JSONField()
    description=models.JSONField()
    quantity=models.JSONField()
    type=models.CharField(max_length=1,choices=(("0","GOLD"),("1","SILVER")))
    timestamp=models.DateTimeField(auto_now_add=True)
    redeem_timestamp=models.DateTimeField(null=True)
    class Meta:
        unique_together=["series","billno","user"]
    def __str__(self):
        return self.user.name
    def delete(self,*args,**kwargs):
        if self.redemption:
            raise 
        super().delete(*args,**kwargs)

class purchaseshop(models.Model):
    user=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    name=models.CharField(max_length=255)
    address=models.IntegerField()
    adno=models.CharField(max_length=255)
    phno=models.CharField(max_length=10)
    email=models.CharField(max_length=255)
    GSTno=models.CharField(max_length=255)
    bankname=models.CharField(max_length=255)
    acno=models.CharField(max_length=100)
    ifsc=models.CharField(max_length=100)
    lastactive=models.DateTimeField(null=True)
    timestamp=models.DateTimeField(null=True)
    def __str__(self):
        return self.user.name
class purchasebill(models.Model):
    user=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    shop=models.ForeignKey(purchaseshop,on_delete=models.CASCADE)
    date_created=models.DateField()
    billno=models.CharField(max_length=10,blank=True,null=True)
    mrate=models.IntegerField()
    amount=models.IntegerField()
    total=models.IntegerField()
    tweight=models.IntegerField()
    type=models.CharField(max_length=1,choices=(("0","GOLD"),("1","SILVER")))
    timestamp=models.DateTimeField()
    def __str__(self):
        return self.user.name

class salebills(models.Model):
    user=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    type=models.CharField(max_length=1,choices=(("0","GOLD"),("1","SILVER")))
    series=models.CharField(max_length=10)
    customer_name=models.ForeignKey(customer,on_delete=models.CASCADE)
    billno=models.IntegerField()
    bill_type=models.CharField(max_length=1,choices=(("0","GST"),("1","ESTIMATE")))
    mrate=models.IntegerField()
    weight=models.IntegerField()
    charge=models.IntegerField()
    amount=models.IntegerField()
    recieved=models.IntegerField()
    date_created=models.DateField()
    timestamp=models.DateTimeField()
    class Meta:
        unique_together=["series","billno","user"]
    def __str__(self):
        return self.user.name
class stockitems(models.Model):
    user=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    item=models.IntegerField()
    bcode=models.CharField(max_length=255)
    weight=models.IntegerField()
    touch=models.IntegerField()
    huid=models.CharField(max_length=255)
    billid=models.ForeignKey(purchasebill,on_delete=models.CASCADE)
    carat=models.CharField(max_length=1,choices=(("0","Carat1"),("1","Carat2")))
    saled=models.IntegerField(null=True)
    size=models.CharField(max_length=20)
    timestamp=models.DateTimeField()
    class Meta:
        unique_together=["user","bcode"]
    def __str__(self):
        return self.user.name
table_choices=(("0","bill_series"),("1","bill_rseries"),("2","bill_jseries"),("3","token_series"),("4","interest"),('5', 'bills'), ('6', 'redeem_bills'), ('7', 'purchasebill'), ('8', 'salebills'), ('9', 'customers'), ('10', 'purchaseshop'), ('11', 'stockitems'),('12', 'saled_stockitems'))
class deleted_records(models.Model):
    user=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    type=models.CharField(max_length=2,choices=table_choices)
    deleted_bid=models.IntegerField()
    deleted_data=models.TextField()
    timestamp=models.DateTimeField(null=True)


