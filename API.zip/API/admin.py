from django.contrib import admin
from .models import *
admin.site.register(address)
admin.site.register(bill_series)
admin.site.register(bill_rseries)
admin.site.register(bill_jseries)
admin.site.register(token_series)
admin.site.register(interest_setting)
admin.site.register(suggestion)
admin.site.register(customer)
admin.site.register(pawn_bills)
admin.site.register(purchasebill)
admin.site.register(purchaseshop)
admin.site.register(salebills)
admin.site.register(stockitems)
admin.site.register(deleted_records)
# Regiser your models here.
