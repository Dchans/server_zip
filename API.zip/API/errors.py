class delete_error(Exception):
    def __init__(self, message="Bill is Redemed"):
        super().__init__(message)