from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser,FormParser
from .serializer import register_ser,login_ser,user_ser,sub_ser
from django.core.files.base import ContentFile
from django.contrib.auth import authenticate
from home.models import User,subscription
import random
from  dchan.encapsulation import fernet
from django.utils import timezone
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from django.http import FileResponse
import json
from Backup.busyness import backup_data_busyness,sync_busyness_backup,convert_id_to_name

class user_login(APIView):
    def post(self,request):
        if request.data.get('name') and request.data.get('password'):
            user=authenticate(name=request.data.get('name'),password=request.data.get('password'))
        if user is not None:
            return Response({'login':True,'token':get_token(user)},status=status.HTTP_200_OK)
        return Response({'login':False},status=status.HTTP_403_FORBIDDEN)
class user_data(APIView):
    permission_classes=[IsAuthenticated]
    def get(self,request):
        data=request.query_params
        type=data.get("type")
        user_data=user_ser(request.user).data
        user_data["db_password"]=fernet.decrypt(user_data["db_password"].encode())
        print(user_data["db_password"])
        if(type=="0"): return Response({"user_data":user_data,"subscription": sub_ser(subscription.objects.get(user=request.user,app_type=0)).data})
        return Response({"error":True})
class register_user(APIView):
    def post(self,request,format=None):
        new_user=register_ser(data=request.data)
        if new_user.is_valid():
            new_user=new_user.save()
            return Response({'created':True,'token':get_token(new_user)})
        return Response({"error":new_user.errors})  

class backup_data(APIView):
    permission_classes=[IsAuthenticated]
    def post(self,request):
        data=json.loads(request.body.decode())
        if data["type"]==0:
            if data["btype"]==2:return Response(backup_data_busyness(request.user,data))
            elif data["btype"]==4:return Response(convert_id_to_name(data["ctype"],data["ids"],request.user))
            return Response({"error":"Invalid Btype"})
        return Response({"error":"Invalid Type"})
    def get(self,request):
        data=request.query_params
        ftype=data.get("type")
        if(ftype=="0"):return Response({"Last_Backup":subscription.objects.get(user=request.user).lastbackup.strftime('%Y-%m-%d %H:%M:%S')})
        elif(ftype=="1"):return Response(sync_busyness_backup(request.user,data.get("time")))
        return Response({"error":"Invalid Type"})
class download_database(APIView):
    permission_classes=[IsAuthenticated]
    def post(self,request):
        data=json.loads(request.POST)
        return Response({'failed':True})                   
def get_token(user):
    referesh=RefreshToken.for_user(user)
    return {'referesh':str(referesh),'access':str(referesh.access_token)}
    

"""class generate_otp(APIView):
    def post(self,request):
        try:
            User.objects.get(phone=request.data.get("phone"))
            return Response({'Exist':True})
        except:
            request.session['otp']=self.generate_otp(request.data.get("phone"))
            print(request.session['otp'])
            return Response({'Generated':True})
    def generate_otp(self,phonenumber):
        otp=random.randint(1000,10000)
        print(otp)
        return str(otp)

class otp_verify(APIView):
        def post(self,request):
            if request.session.get("otp") and request.session.get("phone"):
                if request.data.get("otp")==request.session.get("otp"):
                        ser=register_ser(data={"name":request.session.get("name"),"password":request.session.get("password"),"phone":request.session.get("phone")})
                        del request.session["name"]
                        del request.session["otp"]
                        del request.session["phone"]
                        del request.session["password"]
                        if ser.is_valid(raise_exception=True):
                            ser.save()
                            request.session["db"]=True
                            return Response({'created':True,'token':get_token(ser.user)},status=status.HTTP_201_CREATED)
                        
                        return Response(ser.errors,status=status.HTTP_400_BAD_REQUEST)
                return Response({'otp':False},status=status.HTTP_400_BAD_REQUEST)
            return Response({'otp':False},status=status.HTTP_400_BAD_REQUEST)"""
