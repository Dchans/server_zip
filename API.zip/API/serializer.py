from rest_framework import serializers
from home.models import User,subscription
from API.models import *
import json
from datetime import datetime
class CustomDateTimeField(serializers.Field):
    def to_representation(self, value):
        # Convert the datetime to the desired format
        return value.strftime("%Y-%m-%d %H:%M:%S")
   

    def to_internal_value(self, data):
        # Parse the incoming date-time string into a Python datetime object
        return datetime.strptime(data, "%Y-%m-%d %H:%M:%S")
class register_ser(serializers.ModelSerializer):
    class Meta:
        model=User
        fields=['name','password']
        extra_kwargs={'password':{'write_only':True}}
    def create(self,validate_data):
        user_object=User.objects.create_user(**validate_data)
        if validate_data.get("profile_image"):
            user_object.profile_pic=validate_data.get("profile_image")
        elif validate_data.get("gender")==1:
            user_object.profile_pic='female.jpg'
        return user_object

class login_ser(serializers.ModelSerializer):
    name=serializers.CharField(max_length=200)
    class Meta:
        model=User
        fields=['name','password']
class user_ser(serializers.ModelSerializer):
    class Meta:
        model=User
        fields=['email','phone','profile_pic','gender','db_password']
class sub_ser(serializers.ModelSerializer):
    class Meta:
        model=subscription
        fields=['shop_name','address']
class address_bser(serializers.ModelSerializer):
    class Meta:
        model=address
        fields="__all__"
class pawn_bills_bser(serializers.ModelSerializer):
    timestamp=CustomDateTimeField()
    class Meta:
        model=pawn_bills
        fields="__all__"
class redeem_bills_bser(serializers.ModelSerializer):
    redeem_timestamp=CustomDateTimeField()
    class Meta:
        model=pawn_bills
        fields=["id","billno","series","redemption","rseries","redemptiondate","month","recieved","redeem_timestamp"]
class purchasebill_bser(serializers.ModelSerializer):
    timestamp=CustomDateTimeField()
    class Meta:
        model=purchasebill
        fields="__all__"
class salebill_bser(serializers.ModelSerializer):
    timestamp=CustomDateTimeField()
    class Meta:
        model=salebills
        fields="__all__"
class purchaseshop_bser(serializers.ModelSerializer):
    timestamp=CustomDateTimeField()
    class Meta:
        model=purchaseshop
        fields="__all__"
class stockitems_bser(serializers.ModelSerializer):
    timestamp=CustomDateTimeField()
    class Meta:
        model=stockitems
        fields="__all__"
class suggestion_bser(serializers.ModelSerializer):
    class Meta:
        model=suggestion
        fields="__all__"
class customer_bser(serializers.ModelSerializer):
    timestamp=CustomDateTimeField()
    lastactive=CustomDateTimeField()
    class Meta:
        model=customer
        fields="__all__"
class seriesp_bser(serializers.ModelSerializer):
    timestamp=CustomDateTimeField()
    class Meta:
        model=bill_series
        fields="__all__"
class seriesr_bser(serializers.ModelSerializer):
    timestamp=CustomDateTimeField()
    class Meta:
        model=bill_rseries
        fields="__all__"
class seriesj_bser(serializers.ModelSerializer):
    timestamp=CustomDateTimeField()
    class Meta:
        model=bill_jseries
        fields="__all__"
class seriest_bser(serializers.ModelSerializer):
    timestamp=CustomDateTimeField()
    class Meta:
        model=token_series
        fields="__all__"
class interest_bser(serializers.ModelSerializer):
    timestamp=CustomDateTimeField()
    class Meta:
        model=interest_setting
        fields="__all__"



        
    


    
