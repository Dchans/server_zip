from API.models import *
from django.db.models import Q
import re
class busyness_fetch:
    def fetch(self,itype,data):
        if itype == 0: return self.pawn_bills(data)
        elif itype == 1:return self.fetch_series(self,data)
        elif itype == 2:return self.fetch_customer(self,data)
        elif itype == 3:return self.fetch_redeembills(self,data)
        elif itype == 5:return self.fetch_interest(self,data)
        elif itype == 6:return self.fetch_suggestion(self,data)
        elif itype == 7: return self.fetch_jseries(self,data)
        elif itype == 8: return  self.fetch_salebills(self,data)
        elif itype == 9: return  self.fetch_barcodes(self,data)
        elif itype == 10: return  self.fetch_purchasebills(self,data)
        elif itype == 11: return  self.fetch_stockitems(self,data)
        elif itype == 13: return self.fetch_purchaseshop(self,data)
        elif itype == 14: return self.fetch_card_data(self,data)
        elif itype == 15: return self.fetch_buylist(self,data)
    def pawn_bills(self,data):
        query=data["query"]
        order = '-' if data["query"][3] else ''
        orderq = ["billno", "amount", "weight"][data.query[5]]
        columns_q = ["name", "customers.id", f"billno=%s and series='%s'", "amount", "weight"]
       
        dquery={}
        if (query[0] != ''):
                if query[4] == 0:dquery[columns_q[0]+"__icontains"]=query[0]
                elif data.query[4] == 2: dquery=self.get_billnoq(query[0])
                else:dquery[columns_q[query[4]]]=query[0]
        if query[7]:dquery["redemption__isnull"] =False
        if query[6]:dquery["type"]= query[6] - 1
        dateq=date_query(data.query[1], data.query[2])
        if dateq:dquery.update(dateq)
        bill=pawn_bills.objects.filter(**dquery).order_by(f"{order}series",f"{order}{orderq}")
        print(bill)
            
    def get_billnoq(self,billno):
        series,no=split_bs(billno)
        if series!=None and no!=None:return {"billno":billno,"series":series}
        elif billno.isdigit():return{"billno":billno}
        elif billno:return{"series":billno}

         
def split_bs(billno):
    match = re.match(r"([a-zA-Z]+)([0-9]+)", billno)
    if match:
        alpha_part = match.group(1)
        numeric_part = int(match.group(2))
        return alpha_part, numeric_part
    else:
        return None, None
def date_query(date1,date2):
     if date1 and date2:
          return {"date_created__range":(date1,date2)}
     elif date1:
          return {"date_created":date1}
     elif date2:
          return  {"date_created":date2}
     
          

       