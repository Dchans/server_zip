import re
from API.models import *
import json
import base64
from django.core.files.base import ContentFile
from datetime import datetime
from django.utils import timezone
def convert_dtstring(dtstring=""):
    try:
        timestamp=timezone.make_aware(datetime.strptime(dtstring, "%Y-%m-%d %H:%M:%S"))
        if timestamp>timezone.now():return timezone.now()
        return timezone.make_aware(datetime.strptime(dtstring, "%Y-%m-%d %H:%M:%S"))
    except: 
        return timezone.now()
def convert_dstring(dtstring=""):
    try:
        date= timezone.make_aware(datetime.strptime(dtstring, "%Y-%m-%d")).date()
        if date>timezone.now().date():return timezone.now().date()
        return timezone.make_aware(datetime.strptime(dtstring, "%Y-%m-%d")).date()
    except:return timezone.now().date()
class busyness_insert:
    def __init__(self):
        self.current=None
    def insert(self,itype,data):
        if(itype==0):return self.add_pbill(data)
        elif(itype==3): return self.add_rbill(data)
        elif(itype == 1): return self.add_series(data)
        elif(itype == 5): return self.add_interest(data)
        elif(itype == 2): return self.add_customer(data)
        elif(itype == 8): return self.add_sale(data)
        elif(itype == 13): return self.add_purchaseshop(data)
        elif(itype == 10):return self.add_purchase(data)
        elif(itype==16):return self.add_deleterecord(data)
    def add_series(self,data):
        data["range"]=data["range"]=round(float(data["range"]),3) if data.get("range") and type(data["range"])==int else 0
        data["series"]=data.get("series","")
        if not re.match("^[a-zA-Z]$", data["series"]):return {"save":False, "failed": "Series Cannot Be Empty","error_type": 0 }
        if (data["range"] < 1):return {"save": False, "failed": "Range Cannot Be Less Than 0", "error_type": 1 }
        pre_series=None
        if (pre_series):
            if (data["uid"] != pre_series.id):return {"save":False,"failed": "Series Already Exist!","error_type": 2 }
        if (data["stype"]==0):series_obj=bill_series
        elif(data["stype"]==1):series_obj=bill_rseries
        elif(data["stype"]==2):series_obj=bill_jseries
        elif(data["stype"]==3):series_obj=token_series
        if (data["uid"]):
                try:
                    series_obj=series_obj.objects.get(user=data["user"],id=data["uid"])
                    return {"save":True,"id":series_obj.id,"updated":True,"stype":data["stype"]}
                except series_obj.DoesNotExist:
                    pass
        new_series_obj=series_obj.objects.get_or_create(user=data["user"],series=data["series"])[0]
        new_series_obj.range=data["range"]
        return {"save":True,"id":new_series_obj.id,"updated":False,"stype":data["stype"]}
    def add_interest(self,data):
        data["amount1"]=int(data["amount1"]) if data.get("amount1") and type(data["amount1"])==int else 0
        data["amount2"]=int(data["amount2"]) if data.get("amount2") and type(data["amount2"])==int else 0
        data["rate"]=round(float(data["rate"]),3) if data.get("rate") and type(data["rate"])==int else 0
        if (data["amount1"] > data["amount2"]):return {"save":False,"error_type": 3,"failed": "Amount1 Cannot Be Greather Than Amount2" }
        saved=interest_setting.objects.get_or_create(user=data["user"],amount1=data["amount1"],amount2=data["amount2"],type=data["type"],rate=data["rate"])[0]
        return {"save":True,"id":saved.id}
    def add_pbill(self,data):
        if not data.get("timestamp") :data["timestamp"]=convert_dtstring("")
        else:data["timestamp"]=convert_dtstring(data["timestamp"])
        if not data.get("date_created") :data["date_created"]=convert_dstring()
        else:data["date_created"]=convert_dstring(data["date_created"])
        if not data.get("customer_name") :return { "save": False, "failed": "No Customer Selected", "error_type": 1 }
        if not (data.get("billno") and  data.get("series")):return {"save":False,"failed":"Invalid Billno","error_type": 2 }
        try:
            series=bill_series.objects.get(series=data["series"])
        except bill_series.DoesNotExist:
            return {"save":False, "failed": "Invalid series", "error_type": 4 }
        if (series.range < data["billno"]):return {"save":False, "failed": "Bill No Cannot be greather than range","error_type": 3 } 
        try:
            mindate=pawn_bills.objects.get(user=data["user"],billno=data["billno"],series=data["series"],date_created__lt=data["date_created"])
        except pawn_bills.DoesNotExist:
            mindate=None
        try:
            maxdate=pawn_bills.objects.get(user=data["user"],billno=data["billno"],series=data["series"],date_created__gt=data["date_created"])
        except pawn_bills.DoesNotExist:
            maxdate=None
        if maxdate:
            if data["date_created"] > maxdate.date_created:
                return {"save":False, "failed": f"Date Cannot Be greather than Bill {maxdate.billno}", "error_type": 5 } 
        if mindate:
            if (data["date_created"] < mindate.date_created):
                return {"save": False, "failed": f"Date Cannot Be Less than Bill {mindate.billno}", "error_type": 5 }
        
        for d in range(len(data["items"])):
            sid=suggestion.objects.get_or_create(name=data["items"][d],stype=data["type"],type=0)[0]
            data["items"][d]=sid.id
            sid.count+=1
            sid.save()
        for d in range(len(data["description"])):
            sid=suggestion.objects.get_or_create(name=data["description"][d],stype=data["type"],type=1)[0]
            data["description"][d]=sid.id
            sid.count+=1
            sid.save() 
        data["items"]=data["items"]
        data["description"]=data["description"]
        data["weight"]=round(float(data["weight"]),3) if data.get("weight") and type(data["weight"])==int else 0
        data["amount"]=int(data["amount"]) if data.get("amount") and type(data["amount"])==int else 0
        data["value"]=int(data["value"]) if data.get("value") and type(data["value"])==int else 0
        data["pay"]=int(data["pay"]) if data.get("pay") and type(data["pay"])==int else 0
        if data["weight"] <= 0 :return { "save": False, "failed": "Weight Cannot be Zero","error_type": 8 }
        if data["amount"] <=0 or data["value"] < data["amount"]: return { "save": False, "failed": "Amount Cannot be less then zero or  Greather than value", "error_type": 9 }
        if data['value'] <= 0:return {"save":False, "failed": "Value Cannot be Zero", "error_type": 10 }
        if data["pay"] <= 0 :return {"save": False, 'failed': "Pay Cannot be Zero", 'error_type': 11 }
        if data.get("type") is None:data["type"]=0
        try:
            bill=pawn_bills.objects.get(billno=data["billno"],series=data["series"],user=data["user"])
            if(bill.timestamp>data["timestamp"]):return {"save":False,"failed":"A Record Greather Than The Time exist","error_type":12}
            bill.customer_name_id=data["customer_name"]
            bill.weight=data["weight"]
            bill.value=data["value"]
            bill.date_created=data["date_created"]        
            bill.items=data["items"]
            bill.description=data["description"]
            bill.quantity=data["quantity"]
            bill.amount=data["amount"]
            bill.interest_rate=data["interest_rate"]
            bill.pay=data["pay"]
            bill.timestamp=data["timestamp"]
            bill.type=data["type"]
            bill.type
            bill.save()
            return {"save":True,"id":bill.id,"updated":True}
        except pawn_bills.DoesNotExist:
            bill=pawn_bills.objects.create(user=data["user"],billno=data["billno"],date_created=data["date_created"],series=data["series"],customer_name_id=data["customer_name"],items=data["items"],description=data["description"],quantity=data["quantity"],weight=data["weight"],value=data["value"],amount=data["amount"],interest_rate=data["interest_rate"],pay=data["pay"],timestamp=data["timestamp"],type=data["type"])
            return {"save":True,"id":bill.id,"updated":False}
    def add_rbill(self,data):
            print(data)
            if not data.get("redeem_timestamp") :data["redeem_timestamp"]=convert_dtstring("")
            else:data["redeem_timestamp"]=convert_dtstring(data["redeem_timestamp"])
            if not data.get("redemptiondate") :data["redemptiondate"]=convert_dstring()
            else:data["redemptiondate"]=convert_dstring(data["redemptiondate"])
            try:
                mindate=pawn_bills.objects.get(user=data["user"],redemption=data["redemption"],rseries=data["rseries"],redemptiondate__lt=data["redemptiondate"])
            except pawn_bills.DoesNotExist:
                mindate=None
            try:
                maxdate=pawn_bills.objects.get(user=data["user"],redemption=data["redemption"],rseries=data["rseries"],redemptiondate__gt=data["redemptiondate"])
            except pawn_bills.DoesNotExist:
                maxdate=None
            if maxdate:
                if data["redemptiondate"] > maxdate.redemptiondate:
                    return {"save":False, "failed": f"Date Cannot Be greather than Bill {maxdate.billno}", "error_type": 5 } 
            if mindate:
                if (data["redemptiondate"] < mindate.redemptiondate):
                    return {"save": False, "failed": f"Date Cannot Be Less than Bill {mindate.billno}", "error_type": 5 }
            if not (data.get("redemption") and  data.get("rseries")):return {"save":False,"failed":"Invalid Redempion Billno","error_type": 2 }
            try:
                series=bill_rseries.objects.get(series=data["rseries"])
            except bill_rseries.DoesNotExist:
                return {"save":False, "failed": "Invalid series", "error_type": 4 }
            if (series.range < data["redemption"]):return {"save":False, "failed": "Bill No Cannot be greather than range","error_type": 3 } 
            if not (data.get("billno") and data.get("series")): return {"save": False, "failed": "Bill No Should Be Defined To Redeem", "error_type": 5 }
            data["month"]=int(data["month"]) if data.get("month") and type(data["month"])==int else 1
            data["recieved"]=int(data["recieved"]) if data.get("recieved") and type(data["recieved"])==int else 0
            if (data["month"] < 1):return {"save":False,"failed": "Month Cannot Be less than 1","error_type": 6 }
            if (data["recieved"] < 1):return {"save":False,"failed": "Recieved Cannot be Zero","error_type": 7}
            try:
                pawn_bill=pawn_bills.objects.get(user=data["user"],id=data["uid"])
            except pawn_bills.DoesNotExist:
                return {"save":False,"failed":"Pawn Bill Did Not Found!","error_type":8}
            try:
                redemption_bill=pawn_bills.objects.get(user=data["user"],redemption=data["redemption"],rseries=data["rseries"])
                if(redemption_bill.redeem_timestamp>data["redeem_timestamp"]):return {"save":False,"error_type":9,"failed":"A Redeem Bill Already exist"}
                redemption_bill.redemption=redemption_bill.rseries=redemption_bill.redeem_timestamp=redemption_bill.redemptiondate=None
                redemption_bill.recieved=redemption_bill.month=0 
                redemption_bill.save()
            except pawn_bill.DoesNotExist:
                pass
            pawn_bill.month=data["month"]
            pawn_bill.recieved=data["recieved"]
            pawn_bill.rseries=data["rseries"]
            pawn_bill.redemptiondate=data["redemptiondate"]
            pawn_bill.redemption=data["redemption"]
            pawn_bill.redeem_timestamp=convert_dtstring(data["redeem_timestamp"])
            pawn_bill.save()
            return {"save": True }
    def add_purchase(self,data):
        if not data.get("shop") :return { "save": False, "failed": "No Shop Selected", "error_type": 1 }
        if not data.get("timestamp") :data["timestamp"]=convert_dtstring("")
        else:data["timestamp"]=convert_dtstring(data["timestamp"])
        data["tweight"]=round(float(data["tweight"]),3) if data.get("tweight") and type(data["tweight"])==int else 0
        data["mrate"]=round(float(data["mrate"]),3) if data.get("mrate") and type(data["mrate"])==int else 0
        data["amount"]=int(data["amount"]) if data.get("amount") and type(data["amount"])==int else 0
        data["total"]=int(data["total"]) if data.get("total") and type(data["total"])==int else 0
        if data["mrate"]<=0:return {"save":False,"failed": "Market rate Cannot be Less than Zero", "error_type": 7, "error_index": 5 }
        elif data["tweight"]<=0:return {"save": False, "failed":"Weight Cannot be Less than Zero","error_type": 8, "error_index": 5 }
        elif data["amount"]<=0: return {"save":False, "error_type": 9,"failed": "Amount cannot be 0" }
        elif data["total"] <=0: return {"save": False,"error_type": 10,"failed": "Total  cannot be 0" }
        if data.get("billno") is None:data["billno"]=""
        if data.get("type") is None:data["type"]=0
        try:
            bill=purchasebill.objects.get(user=data["user"],id=data["uid"])
            if bill.timestamp>data["timestamp"]:
                return {"save":False,"error_type":12,"failed":"A Record Already Exist!"}
            bill.shop_id=data["shop"]
            bill.date_created=data["date_created"]
            bill.billno=data["billno"]
            bill.mrate=data["mrate"]
            bill.amount=data["amount"]
            bill.total=data["total"]
            bill.tweight=data["tweight"]
            bill.type=data["type"]
            bill.timestamp=data["timestamp"]
            bill.save() 
            stockitems.objects.filter(user=data["user"],billid=bill.id).delete()
        except purchasebill.DoesNotExist:
            bill=purchasebill.objects.create(user=data["user"],billno=data["billno"],shop_id=data["shop"],date_created=data["date_created"],mrate=data["mrate"],amount=data["amount"],total=data["total"],tweight=data["tweight"],type=data['type'],timestamp=data["timestamp"])
        result={"save":True,"id":bill.id,"stockids":{}}
        for item_data in data["items"]:
            try:
                item_data["timestamp"]=convert_dtstring(item_data["timestamp"])
                sid=suggestion.objects.get_or_create(name=json.dumps({'name':item_data["name"],'hsn':item_data['hsn']}),stype=item_data["type"],type=2)[0]
                sid.count+=1
                sid.save()
                try:
                    stock_exist=stockitems.objects.get(user=data["user"],bcode=item_data["bcode"])
                    stock_exist.item=sid.id
                    stock_exist.weight=item_data["weight"]
                    stock_exist.touch=item_data["touch"]
                    stock_exist.huid=item_data["huid"]
                    stock_exist.billid_id=bill.id
                    stock_exist.carat=item_data["carat"]
                    stock_exist.size=item_data["size"]
                    stock_exist.timestamp=item_data["timestamp"]
                    stock_exist.save()
                    result["stockids"][item_data["bcode"]]=stock_exist.id
                except stockitems.DoesNotExist:
                    result["stockids"][item_data["bcode"]]=stockitems.objects.create(user=data["user"],billid_id=bill.id,bcode=item_data["bcode"],item=sid.id,weight=item_data["weight"],touch=item_data["touch"],huid=item_data["huid"],carat=item_data["carat"],size=item_data["size"],timestamp=item_data["timestamp"]).id
            except Exception as e:
                print(e)
                pass
        return result
    def add_sale(self,data):
            if not data.get("timestamp") :data["timestamp"]=convert_dtstring("")
            else:data["timestamp"]=convert_dtstring(data["timestamp"])
            if not data.get("date_created") :data["date_created"]=convert_dstring()
            else:data["date_created"]=convert_dstring(data["date_created"])
            if not data.get("customer_name") :return { "save": False, "failed": "No Customer Selected", "error_type": 1 }
            if not (data.get("billno") and  data.get("series")):return {"save":False,"failed":"Invalid Billno","error_type": 2 }
            try:
                series=bill_jseries.objects.get(series=data["series"])
            except bill_jseries.DoesNotExist:
                return {"save":False, "failed": "Invalid series", "error_type": 4 }
            if (series.range < data["billno"]):return {"save":False, "failed": "Bill No Cannot be greather than range","error_type": 3 } 
            try:
                mindate=salebills.objects.get(user=data["user"],billno=data["billno"],series=data["series"],date_created__lt=data["date_created"])
            except salebills.DoesNotExist:
                mindate=None
            try:
                maxdate=salebills.objects.get(user=data["user"],billno=data["billno"],series=data["series"],date_created__gt=data["date_created"])
            except salebills.DoesNotExist:
                maxdate=None
            if maxdate:
                if data["date_created"] > maxdate.date_created:
                    return {"save":False, "failed": f"Date Cannot Be greather than Bill {maxdate.billno}", "error_type": 5 } 
            if mindate:
                if (data["date_created"] < mindate.date_created):
                    return {"save": False, "failed": f"Date Cannot Be Less than Bill {mindate.billno}", "error_type": 5 }
            data["weight"]=round(float(data["weight"]),3) if data.get("weight") and type(data["weight"])==int else 0
            data["mrate"]=round(float(data["mrate"]),3) if data.get("mrate") and type(data["mrate"])==int else 0
            data["amount"]=int(data["amount"]) if data.get("amount") and type(data["amount"])==int else 0
            data["recieved"]=int(data["recieved"]) if data.get("recieved") and type(data["recieved"])==int else 0
            data["charge"]=int(data["charge"]) if data.get("charge") and type(data["charge"])==int else 0
            if data["mrate"]<=0:return {"save":False,"failed": "Market rate Cannot be Less than Zero", "error_type": 7, "error_index": 5 }
            elif data["weight"]<=0:return {"save": False, "failed":"Weight Cannot be Less than Zero","error_type": 8, "error_index": 5 }
            elif data["amount"]<=0: return {"save":False, "error_type": 9,"failed": "Amount cannot be 0" }
            elif data["recieved"] <=0: return {"save": False,"error_type": 10,"failed": "Recieved  cannot be 0" }
            if not data.get("billtype"):data["billtype"]=0
            try:
                bill=salebills.objects.get(user=data["user"],billno=data["billno"],series=data["series"])
                stockitems.objects.filter(saled=bill.id,user=data["user"]).update(saled=None)
            except salebills.DoesNotExist:
                bill=salebills.objects.create(user=data["user"],billno=data["billno"],series=data["series"])
            stockitems.objects.filter(bcode__in=data["bcode"],user=data["user"]).update(saled=bill.id)
            return {"save":True,"id":bill.id}
    def add_customer(self,data):
        if data.get("timestamp"):data["timestamp"]=convert_dtstring(data["timestamp"])
        else:data["timestamp"]=convert_dtstring()
        if data.get("lastactive"):data["lastactive"]=convert_dtstring(data["lastactive"])
        else:data["lastactive"]=data["timestamp"]
        data["name"]=data.get("name","")
        data["relation"]=data.get("relation",0)
        data["relation_name"]=data.get("relation","")
        data["address1"]=data.get("address1","")
        data["address2"]=data.get("address2","")
        data["address3"]=data.get("address3","")
        data["pincode"]=data.get("pincode","")
        data["phone"]=data.get("phone","")
        data["email"]=data.get("email","")
        data["otherval"]=data.get("otherval","")
        print(data)
        if data["name"]=="": return {"save":False,"failed": "Invalid Name", "error_type": 0 }
        if not (data["relation"] == 0 or data["relation"] == 1 or data["relation "]== 2): return {"save":False,"failed": "Invalid Relation","error_type": 1 }
        if data["relation_name"]=="":return {"save":False,"failed": "Invalid RelationName","error_type": 2 }
        if not re.match(r'^[6-9]\d{9}$',data["phone"]):data["phone"]=""
        if not re.match(r'^[^\s@]+@[^\s@]+\.[^\s@]+$',data["email"]):data['email']= ""
        if data["address1"]=="":return { "save":False, "failed": "Invalid Address", "error_type": 4 }
        if data["address2"]=="":return {"save":False, "failed": "Invalid Address", "error_type": 5 }
        if data["address3"]=="":return {"save":False, "failed": "Invalid Address", "error_type": 6 }
        if data["pincode"]=="":return {"save":False, "failed": "Invalid Address", "error_type": 7 }
        aid=address.objects.get_or_create(address1=data["address1"],address2=data["address2"],address3=data["address3"],pincode=data["pincode"])[0].id
        try:
            customer_obj=customer.objects.get(id=data["uid"],user=data["user"])
        except customer.DoesNotExist:
            customer_obj=customer.objects.get_or_create(user=data["user"],name=data["name"],relation=data["relation"],relation_name=data["relation_name"],adno=data["adno"],address=aid,phno=data["phno"],email=data["email"],otherval=data["otherval"])[0]
        if customer_obj.timestamp is not None:
            if customer_obj.timestamp>data["timestamp"]:
                return {"save":False,"failed":"A Customer Already Exist","error_type":8}
        customer_obj.timestamp=data["timestamp"]
        customer_obj.lastactive=data["lastactive"]
        result={"save":True,"id":customer_obj.id,"image_error":False}
        if(data.get("image")):
            try:
                format, imgstr = data["image"].split(';base64,') 
                ext = format.split('/')[-1] 
                customer_obj.image= ContentFile(base64.b64decode(imgstr), name=f"{data['user'].id}_{customer_obj.id}." + ext)
            except Exception as e:
                result["image_error"]=e
        customer_obj.save()
        return result
    def add_purchaseshop(self,data):
        if data.get("timestamp"):data["timestamp"]=convert_dtstring(data["timestamp"])
        else:data["timestamp"]=convert_dtstring()
        if data.get("lastactive"):data["lastactive"]=convert_dtstring(data["lastactive"])
        else:data["lastactive"]=data["timestamp"]
        data["phone"]=data.get("phone","")
        data["email"]=data.get("email","")
        data["GSTno"]=data.get("GSTno","")
        data["bankname"]=data.get("bankname","")
        data["acno"]=data.get("acno","")
        data["ifsc"]=data.get("ifsc","")
        if not re.match(r'^[6-9]\d{9}$',data["phone"]):data["phone"]=""
        if not re.match(r'^[^\s@]+@[^\s@]+\.[^\s@]+$',data["email"]):data['email']= ""
        if (data["address1"]==""):return { "save":False, "failed": "Invalid Address", "error_type": 4 }
        if (data["address2"]==""):return {"save":False, "failed": "Invalid Address", "error_type": 5 }
        if (data["address3"]==""):return {"save":False, "failed": "Invalid Address", "error_type": 6 }
        if (data["pincode"]==""):return {"save":False, "failed": "Invalid Address", "error_type": 7 }
        aid=address.objects.get_or_create(address1=data["address1"],address2=data["address2"],address3=data["address3"],pincode=data["pincode"])[0].id
        try:
            purchaseshop_obj=purchaseshop.objects.get(id=data["uid"],user=data["user"])
        except purchaseshop.DoesNotExist:
            purchaseshop_obj=purchaseshop.objects.get_or_create(user=data["user"],name=data["name"],address=aid,adno=data["adno"],phno=data["phno"],email=data["email"],GSTno=data["GSTno"],bankname=data["bankname"],acno=data["acno"],ifsc=data["ifsc"])[0]
        if purchaseshop_obj.timestamp is not None:
            if purchaseshop_obj.timestamp>data["timestamp"]:
                return {"save":False,"failed":"A Purchaseshop Already Exist","error_type":8}
        purchaseshop_obj.lastactive=data["lastactive"]
        purchaseshop_obj.timestamp=data["timestamp"]
        purchaseshop_obj.save()
        return {"save":True,"id":purchaseshop_obj.id}
    def add_deleterecord(self,data):
        data["uid"]=data.get("uid",None)
        if(data["uid"]):
            try:
                delete_record=deleted_records.objects.get(user=data["user"],id=data["uid"])
                delete_record.deleted_data=data["deleted_data"]
                delete_record.deleted_bid=data["deleted_uid"]
                delete_record.save()
            except deleted_records.DoesNotExist:
                return {"save":False,"update":False,"failed":"Record not found"}
        delete_record=deleted_records.objects.create(user=data["user"],id=data["uid"],deleted_data=data["deleted_data"],deleted_bid=data["uid"])
        delete_record.save()
        return {"save":True,"id":delete_record.id}