from API.models import *
from API.errors import delete_error
from django.db.models import F
class busyness_delete:
    def __init__(self):
        self.current=None
    def delete(self,itype,data):
        if itype == 0: return self.delete_bill(data)
        elif itype == 1: return self.delete_rbill(data)
        elif itype == 8:return self.delete_salebill(data)
        elif itype == 4:return self.delete_customer(data)
        elif itype == 10: return self.delete_purchasebill(data)
        elif itype==14: return self.delete_interest(data)
        elif itype==15: return self.delete_series(data)
    def delete_bill(self,data):
        try:
            bill=pawn_bills.objects.get(user=data["user"],id=data["id"])
            bill.delete()
            suggestion.objects.filter(type=0,id__in=bill.items).update(count=F('count')-1)
            suggestion.objects.filter(type=1,id__in=bill.description).update(count=F('count')-1)
        except pawn_bills.DoesNotExist:
            return {"save":False,"failed":"Bill Not Found"}
        except delete_error:
            return {"save":False,"failed":"Bill Is redemed"}
    def delete_rbill(self,data):
        try:
            redemption_bill=pawn_bills.objects.get(user=data["user"],id=data["id"])
            redemption_bill.redemption=redemption_bill.rseries=redemption_bill.redeem_timestamp=redemption_bill.redemptiondate=None
            redemption_bill.recieved=redemption_bill.month=0
        except pawn_bills.DoesNotExist:
            return {"save":False,"failed":"Bill Not Found"} 
    def delete_salebill(self,data):
        try:
            salebill=salebills.objects.get(user=data["user"],id=data["id"])
            stockitems.objects.filter(saled=salebill).update(saled=None)
        except salebills.DoesNotExist:
            return {"save":False,"failed":"Bill Not Found"} 
    def delete_customer(self,data):
        try:
            pawn_bills.objects.get(user=data["user"],customer_name=data["id"])
            return {"save":False,"failed":"A Pawn Bill Exist Failed To delete!"}
        except pawn_bills.DoesNotExist:
            pass
        try:
            salebills.objects.get(user=data["user"],customer_name=data["id"])
            return {"save":False,"failed":"A Sale Bill Exist Failed To delete!"}
        except salebills.DoesNotExist:
            pass
        try:
            customer.objects.get(user=data["user"],id=data["id"]).delete()
            return {"save":True}
        except customer.DoesNotExist:
            return {"save":False,"failed":"Customer Not Exist"}
    def delete_purchasebill(self,data):
        try:
            pbill=purchasebill.objects.get(user=data["user"],id=data["id"])
            if stockitems.objects.filter(billid=pbill).exclude(saled=None).exists():
                return {"save":False,"failed":"A Saled Stockitem Exist!"}
            pbill.delete()
        except purchasebill.DoesNotExist:
            return {"save":False,"failed":"Purchasebill Not Exist"}
    def delete_interest(self,data):
        try:
            interest_setting.objects.get(user=data["user"],id=data["id"]).delete()
            return {"save":True}
        except interest_setting.DoesNotExist:
            return {"save":False,"failed":"Interest Setting Not Found!"}
    def delete_series(self,data):
        return {"save":False}

        





    
