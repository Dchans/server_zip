from datetime import datetime
from django.utils import timezone
from CRUD.Busyness.delete import busyness_delete 
from CRUD.Busyness.insert import busyness_insert
from CRUD.Busyness.fetch import busyness_fetch

delete_obj=busyness_delete()
insert_obj=busyness_insert()
fetch_obj=busyness_fetch()

class crud:
    def insert(self,type,data):
        return insert_obj.insert(type,data)
    def delete(self,type,data):
        return delete_obj.delete(type,data)
    def fetch(self,type,data):
        return fetch_obj.fetch(type,data)
busyness_crud=crud()


