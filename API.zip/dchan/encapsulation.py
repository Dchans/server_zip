from cryptography.fernet import Fernet
from django.conf import settings
fernet=Fernet(settings.SECRET_KEY)