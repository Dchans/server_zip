
from API.serializer import *
from API.models import *
from home.models import subscription
from CRUD.Busyness.init import busyness_crud
from django.utils import timezone
from CRUD.Busyness.insert import convert_dtstring
def backup_data_busyness(user,all_data):
    ids={}
    backup_type=all_data["backup_type"]
    all_data=all_data["data"]
    if(backup_type==11):
        for data in all_data:
            data["user"]=user
            ids[data["id"]]=busyness_crud.delete(backup_type,data["id"])
    else:
        for data in all_data:
            data["user"]=user
            ids[data["id"]]=busyness_crud.insert(backup_type,data)
    sub=subscription.objects.get(user=user,app_type=0)
    sub.lastbackup=timezone.now()
    sub.save()
    return ids
def sync_busyness_backup(user,time):
    if(time==""):time="2024-03-10 00:00:00"
    time=convert_dtstring(time)
    data={
        "customers":customer_bser(customer.objects.filter(timestamp__gt=time,user=user).all(),many=True).data,
        "purchaseshop":purchaseshop_bser(purchaseshop.objects.filter(timestamp__gt=time,user=user).all(),many=True).data,
        "pseries":seriesp_bser(bill_series.objects.filter(timestamp__gt=time,user=user).all(),many=True).data,
        "rseries":seriesr_bser(bill_rseries.objects.filter(timestamp__gt=time,user=user).all(),many=True).data,
        "jseries":seriesj_bser(bill_jseries.objects.filter(timestamp__gt=time,user=user).all(),many=True).data,
        "tseries":seriest_bser(token_series.objects.filter(timestamp__gt=time,user=user).all(),many=True).data,
        "pbills":pawn_bills_bser(pawn_bills.objects.filter(timestamp__gt=time,user=user).all(),many=True).data,
        "purchasebills":purchasebill_bser(purchasebill.objects.filter(timestamp__gt=time,user=user).all(),many=True).data,
        "salebills":salebill_bser(salebills.objects.filter(timestamp__gt=time,user=user).all(),many=True).data,
        "redeembills":redeem_bills_bser(pawn_bills.objects.filter(redeem_timestamp__gt=time,user=user).all(),many=True).data,
        "interest_setting":interest_bser(interest_setting.objects.filter(timestamp__gt=time,user=user).all(),many=True).data,
    }
    return data
def convert_id_to_name(type,ids,user=None):
    if(type==3):
        print(ids)
        return address_bser(address.objects.get(id=ids)).data
    elif(type==4):
        return stockitems_bser(stockitems.objects.filter(user=user,billid_id__in=ids).all(),many=True).data 
    converted=[]
    for id in ids:
        converted.append(suggestion_bser(suggestion.objects.get(id=id,type=type)).data)
    return converted

   

    
            
        




    
            

