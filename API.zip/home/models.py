from django.db import models
from django.contrib.auth.models import BaseUserManager, AbstractBaseUser
from dchan.encapsulation import fernet
import random
import string
class MyUserManager(BaseUserManager):
    def create_user(self,name,password=None,password2=None):
        if not name:
            raise ValueError("Users must have a Name")
        user = self.model(name=name,db_password=fernet.encrypt(''.join(random.choice(string.ascii_lowercase) for i in range(7)).encode()).decode())
        user.set_password(password)
        user.save(using=self._db)
        return user
    def create_superuser(self,name,email,password=None):
        user = self.create_user(password=password,name=name)
        user.is_admin = True
        user.save(using=self._db)
        return user
Gender_choices=[("0", 'Male'),("1",'Female')]
class User(AbstractBaseUser):
    email = models.EmailField(verbose_name="Email Address",max_length=255)
    name=models.CharField(max_length=200,unique=True)
    phone=models.CharField(verbose_name="Phone Number",max_length=15,default=None,null=True,blank=True)
    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    objects = MyUserManager()
    USERNAME_FIELD = "name"
    REQUIRED_FIELDS = ["email"]
    profile_pic = models.ImageField(upload_to="profile_pic/",default="male.jpg", null=True, blank=True)
    gender=models.CharField(max_length=1,choices=Gender_choices,default="0")
    storage_size=models.FloatField(default=5)
    db_password=models.TextField()
    otp_limit=models.IntegerField(default=6)
    def __str__(self):
        return self.name

    def has_perm(self, perm, obj=None):
        return self.is_admin

    def has_module_perms(self, app_label):
        "Does the user have permissions to view the app `app_label`?"
        # Simplest possible answer: Yes, always
        return True

    @property
    def is_staff(self):
        return self.is_admin
APP_choices=[("0", 'Busyness'),]
class subscription(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    app_type=models.CharField(max_length=1, choices=APP_choices)
    active=models.BooleanField(default=False)
    date_created=models.DateTimeField(auto_now_add=True)
    shop_name=models.CharField(max_length=200)
    address=models.CharField(max_length=200,default=" ", null=False, blank=False)
    lastbackup=models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.user.name

V_CHOICES = [("0", 'Phone'),("1","Email")]


  

